import React from "react";

function TableHeader() {
    return (
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Job</th>
                <th>Actions</th>
            </tr>
        </thead>
    );
}

function TableBody({ characterData, removeCharacter }) {
    return (
        <tbody>
            {characterData.map((character) => (
                <tr key={character._id}>
                    <td>{character._id}</td>
                    <td>{character.name}</td>
                    <td>{character.job}</td>
                    <td>
                        <button onClick={() => removeCharacter(character._id)}>
                            Delete
                        </button>
                    </td>
                </tr>
            ))}
        </tbody>
    );
}

function Table({ characterData, removeCharacter }) {
    return (
        <table>
            <TableHeader />
            <TableBody characterData={characterData} removeCharacter={removeCharacter} />
        </table>
    );
}

export default Table;
