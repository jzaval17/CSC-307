import React, { useState, useEffect } from "react";

function Form({ handleSubmit, editData }) {
  const [person, setPerson] = useState({
    _id: editData?._id || "",
    name: "",
    job: ""
  });

  useEffect(() => {
    // If editData changes, update the form state
    if (editData) {
      setPerson({
        _id: editData._id,
        name: editData.name,
        job: editData.job
      });
    }
  }, [editData]);

  function handleChange(event) {
    const { name, value } = event.target;
    setPerson(prev => ({ ...prev, [name]: value }));
  }

  function submitForm() {
    handleSubmit(person);
    setPerson({ name: "", job: "" }); // Reset form after submission
  }

  return (
    <form>
      <label htmlFor="name">Name</label>
      <input type="text" name="name" id="name" value={person.name} onChange={handleChange} />
      <label htmlFor="job">Job</label>
      <input type="text" name="job" id="job" value={person.job} onChange={handleChange} />
      <input type="button" value="Submit" onClick={submitForm} /> 
    </form>
  );
}

export default Form;
